/!***--This website is created for our math class in an attempt to combat another math class with way better skill and equipment. --***!\
And clearly I have the best computer in class so I am off for all the work, and here you see me trying to sppedrun a simple README.
We did this "in an attempt" because before this website is even launched, the opposing class's website got discovered and is forced to be removed. 
They used a way too obvious name, so I made our's name a bit more abstract. 
This website comes in two languages, and I am considering adding German as a third one, and fits better with our class theology. 
The problem is that the Holy Melody only comes in Chinese and only in Chinese you can see how it's funny (see the About section of the website). 
The video was completely self made with pirated After Effects which took me half a fricking hour. 
I am also thinking about adding a BGM to the website as the viewer browses, but I haven't decided which song to use. 
